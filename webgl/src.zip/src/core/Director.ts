import { Node } from "./renderer/base/Node";

export namespace sy{
    export  class Director{
          constructor(){

          }
          private scenes:Array<Node>
    }
}