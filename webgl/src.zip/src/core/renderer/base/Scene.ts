
import { Node } from "./Node";

/**
 * 场景的根节点
 */
export default class Scene extends Node{
    constructor(){
        super();
    }
}