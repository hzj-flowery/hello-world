export const CC_EDITOR = false;
export const CC_TEST = false;
export const CC_DEV = false;
